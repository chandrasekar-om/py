| Language | Framework | Platform | Author |
| -------- | -------- |--------|--------|
| Python | Bottle | Windows| Srikrithi, Srinithi |


# Indian Culture & Heritage web application built on Bottle framework

This is a Indian Culture & Heritage Bottle web application that you can use to deploy on Windows.

This sample application is built using Atom.

## License:

See [License] Srikrithi, Srinithi

## Contributing

This project has build in [Python Bottle] (http://bottlepy.org/docs/dev/index.html)).
Contact [srikrithi@example.com](mailto:srikrithi@example.com)[srinithi@example.com](mailto:srinithi@example.com) with any additional questions or comments.
